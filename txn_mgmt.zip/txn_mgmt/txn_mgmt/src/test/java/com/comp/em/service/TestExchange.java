package com.comp.em.service;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.comp.em.repository.ExchangeRepository;
import com.comp.em.repository.ExchangeRepositoryImpl;

public class TestExchange {
	
	
	  private ExchangeRepository exchangeRepository;
	  private BlockOrderMatching blockOrderMatching;
	  private StatusUpdation statusUpdation;
	  private PriceUpdation priceUpdation;
	  
	  
	  @Before
	  public void setUp() {
		  
		  exchangeRepository = new ExchangeRepositoryImpl();
		  priceUpdation = new PriceUpdationImpl();
		  blockOrderMatching = new BlockOrderMatchingImpl(exchangeRepository,priceUpdation);
		  blockOrderMatching.init();
		  statusUpdation = new StatusUpdationImpl();	  
	  }
	  
	  //mockito needed
	  @Ignore
	  @Test
	  public void shouldMatchOrdersForExecution() {
		  
		 blockOrderMatching.matchOrders();
		 assertTrue(true);
	  }
	  
	  @Test
	  public void shouldUpdateStatusAfterExection() {
		  
		  blockOrderMatching.matchOrders();
		  statusUpdation.statusUpdate();
		  assertTrue(true);	  
		  
	  }

}
