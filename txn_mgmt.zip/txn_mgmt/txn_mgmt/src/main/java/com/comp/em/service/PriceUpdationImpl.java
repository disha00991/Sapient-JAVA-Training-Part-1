package com.comp.em.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import com.comp.em.db.MySQLConnection;

public class PriceUpdationImpl implements PriceUpdation {
	
	@Override
	public void priceUpdate(int buy_qty, int sell_qty, String symbol) {
		Connection con = null;

		try {
			con = MySQLConnection.getExchangeConnection();

			String sql1 = "select MarketPrice from em.exchng_stocks where Symbol = ?";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setString(1, symbol);
			ResultSet rs1 = ps1.executeQuery();
			
			while(rs1.next()) {

			double price = rs1.getDouble(1);
			 DecimalFormat df2 = new DecimalFormat(".##");
			String sql2 = "update em.exchng_stocks set MarketPrice = ?, Indicator = ? where Symbol = ?";
			PreparedStatement ps2 = con.prepareStatement(sql2);
			
			if (buy_qty >= sell_qty) {
				price = Math.random() * 10 + price;
				double price1=Double.parseDouble(df2.format(price));
				ps2.setDouble(1, price1);
				ps2.setString(3, symbol);
				ps2.setInt(2, 1);
				

			}
			else {
				price = Math.random() * (-5) + price;
				double price1=Double.parseDouble(df2.format(price));
			
				ps2.setDouble(1, price1);
				ps2.setString(3, symbol);
				ps2.setInt(2, -1);
			}
			ps2.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}

