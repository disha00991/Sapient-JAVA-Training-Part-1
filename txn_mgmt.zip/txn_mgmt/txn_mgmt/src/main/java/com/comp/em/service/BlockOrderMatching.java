package com.comp.em.service;

public interface BlockOrderMatching {

	void init();

	void matchOrders();
	
}