package com.comp.em.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.comp.em.db.MySQLConnection;

public class StatusUpdationImpl implements StatusUpdation {
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.comp.repository.StatusUpdate#save()
	 */
	public void statusUpdate() {
		Connection con1 = null;
		Connection con2 = null;
		
		
		try {
			con1 = MySQLConnection.getExchangeConnection();
			con2 = MySQLConnection.getTradeConnection();

            
			Statement stmt1 = con1.createStatement();
			ResultSet rs1 = stmt1.executeQuery("select * from em.order_matching");
			
			Statement stmt2 = con2.createStatement();
			ResultSet rs2 = stmt2.executeQuery("select * from tm.block_exec");

			while (rs1.next() && rs2.next()) {

				int status = rs1.getInt(7);

				String sql1 = "insert into em.status_update values(?,?,?)";
				PreparedStatement ps1 = con1.prepareStatement(sql1);

				if (status == 3) {
					ps1.setInt(1, rs1.getInt(1));
					ps1.setString(2, "completed");
					int exec = rs2.getInt(5);
					ps1.setInt(3, exec);
				}

				else if (status == 1) {
					if (rs1.getString(8).equals("buy") && rs2.getString(4).equals("buy")) {
						ps1.setInt(1, rs1.getInt(1));
						ps1.setString(2, "pending");
						ps1.setInt(3,0);
					}

					else if (rs1.getString(8).equals("sell") && rs2.getString(4).equals("sell")) {
						ps1.setInt(1, rs1.getInt(1));
						ps1.setString(2, "pending");
						ps1.setInt(3, 0);
					}
				}

				else if (status == 2) {
					if (rs1.getString(8).equals("buy") && rs2.getString(4).equals("buy")) {
						ps1.setInt(1, rs1.getInt(1));
						ps1.setString(2, "partial");
						int exec = rs2.getInt(5)-rs1.getInt(3);
						ps1.setInt(3, exec);
					}

					else if (rs1.getString(8).equals("sell") && rs2.getString(4).equals("sell")) {
						ps1.setInt(1, rs1.getInt(1));
						ps1.setString(2, "partial");
						int exec = rs2.getInt(5)-rs1.getInt(3);
						ps1.setInt(3, exec);
					}
				}
				ps1.executeUpdate();
			}
			
			
			while (rs2.next()) {
				String sql1 = "insert into em.status_update values(?,?,?)";
				PreparedStatement ps2 = con1.prepareStatement(sql1);

				if (rs2.getString(3).equalsIgnoreCase("market")) {
					ps2.setInt(1, rs2.getInt(1));
					ps2.setString(2, "completed");
					int exec = rs2.getInt(5);
					ps2.setInt(3,exec);

					ps2.executeUpdate();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}