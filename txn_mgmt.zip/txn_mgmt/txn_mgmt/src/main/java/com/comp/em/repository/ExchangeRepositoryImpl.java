package com.comp.em.repository;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.comp.em.db.MySQLConnection;

public class ExchangeRepositoryImpl implements ExchangeRepository {
	
	@Override
	public void insertIntoExchange() {
		Connection exchangeConn = null;
		Connection tradeConn = null;
		try {
			//change final connection name
			tradeConn = MySQLConnection.getTradeConnection();
			exchangeConn = MySQLConnection.getExchangeConnection();

			PreparedStatement stmt = tradeConn.prepareStatement("select * from tm.block_exec");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String type = rs.getString(3);
				String side = rs.getString(4);
				if (type.equalsIgnoreCase("limit")) {
					String sql = "insert into em.order_matching values(?,?,?,?,?,?,?,?)";
					PreparedStatement ps = exchangeConn.prepareStatement(sql);
					ps.setInt(1, rs.getInt(1));
					ps.setString(2, rs.getString(2));
					if (side.equalsIgnoreCase("buy")) {
						ps.setInt(3, rs.getInt(5));
						ps.setNull(4, java.sql.Types.INTEGER);
						ps.setDouble(5, rs.getDouble(6));
						ps.setNull(6, java.sql.Types.DOUBLE);
					} else if(side.equalsIgnoreCase("sell")){
						ps.setNull(3, java.sql.Types.INTEGER);
						ps.setInt(4, rs.getInt(5));
						ps.setNull(5, java.sql.Types.DOUBLE);
						ps.setDouble(6, rs.getDouble(6));
					}
					ps.setInt(7, 1);
					ps.setString(8, side);
					ps.executeUpdate();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (tradeConn != null && exchangeConn != null) {
				try {
					tradeConn.close();
					exchangeConn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void orderSegregation() {
		Connection exchangeConn = null;
		PreparedStatement ps = null;
		Statement stmt = null;
		try {
			//change final connection name
			exchangeConn = MySQLConnection.getExchangeConnection();
			stmt = exchangeConn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from em.order_matching");
			while (rs.next()) {
				String side = rs.getString(8);
				if (side.equals("buy")) {
					String sql = "insert into em.buy values(?,?,?,?)";
					ps = exchangeConn.prepareStatement(sql);
					ps.setInt(1, rs.getInt(1));
					ps.setString(2, rs.getString(2));
					ps.setInt(3, rs.getInt(3));
					ps.setDouble(4, rs.getDouble(5));
				} else {
					String sql = "insert into em.sell values(?,?,?,?)";
					ps = exchangeConn.prepareStatement(sql);
					ps.setInt(1, rs.getInt(1));
					ps.setString(2, rs.getString(2));
					ps.setInt(3, rs.getInt(4));
					ps.setDouble(4, rs.getDouble(6));
				}
				ps.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (exchangeConn != null) {
				try {
					exchangeConn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void cleanTxnTables() {
		PreparedStatement ps = null;
		Connection con = null;
		String sql;
		try {
			con = MySQLConnection.getExchangeConnection();
			
			sql = "truncate table em.order_matching";
			ps = con.prepareStatement(sql);
			ps.executeUpdate();
			
			sql = "truncate table em.buy";
			ps = con.prepareStatement(sql);
			ps.executeUpdate();
			
			sql = "truncate table em.sell";
			ps = con.prepareStatement(sql);
			ps.executeUpdate();
			
			sql = "truncate table em.temp";
			ps = con.prepareStatement(sql);
			ps.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
