package com.comp.em.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.comp.em.db.MySQLConnection;
import com.comp.em.repository.ExchangeRepository;

public class BlockOrderMatchingImpl implements BlockOrderMatching {

	private ExchangeRepository exchangeRepository;
	private PriceUpdation stock;

	public BlockOrderMatchingImpl(ExchangeRepository exchangeRepository,PriceUpdation stock) {

		this.exchangeRepository = exchangeRepository;
		this.stock = stock;
	}

	@Override
	public void init() {

		exchangeRepository.cleanTxnTables();
		exchangeRepository.insertIntoExchange();
		exchangeRepository.orderSegregation();
		//stock = new PriceUpdationImpl();
	}

	@Override
	public void matchOrders() {
		PreparedStatement stmt = null;
		int index = 0;
		int size = 0;
		try {
			// clean the tables to be used to prevent re-execution of old blocks
			Connection con = MySQLConnection.getExchangeConnection();
			stmt = con.prepareStatement(
					"insert into em.temp (select * from em.buy b join em.sell s on b.symbol=s.symbol)");
			stmt.executeUpdate();

			stmt = con.prepareStatement("select count(*) from em.temp");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				size = rs.getInt(1);
			}

			while (index < size) {
				stmt = con.prepareStatement("select * from em.temp limit " + (index++) + ", 1");
				rs = stmt.executeQuery();
				if (rs.next()) {

					int bqty = rs.getInt(3);
					int sqty = rs.getInt(7);
					int orderStatus_buy = 1;
					int orderStatus_sell = 1;
					boolean updateNeeded = true;
					double bprice = rs.getDouble(4);
					double sprice = rs.getDouble(8);

					if (bprice >= sprice && bqty == sqty) {
						bqty = 0;
						sqty = 0;
						orderStatus_buy = 3;
						orderStatus_sell = 3;
					} else if (bprice >= sprice && bqty > sqty && sqty != 0) {
						bqty = bqty - sqty;
						sqty = 0;
						orderStatus_buy = 2;
						orderStatus_sell = 3;
					} else if (bprice >= sprice && bqty < sqty && bqty != 0) {
						sqty = sqty - bqty;
						bqty = 0;
						orderStatus_buy = 3;
						orderStatus_sell = 2;
					} else {
						System.out.println("For Block ID: " + rs.getInt(1) + ", " + rs.getInt(5) + " Order Not Executed");
						updateNeeded = false;
					}

					// updating executed status in order_matching table
					stmt = con.prepareStatement("update order_matching set buy_qty=? where block_id=?");
					stmt.setInt(1, bqty);
					stmt.setInt(2, rs.getInt(1));
					stmt.executeUpdate();

					stmt = con.prepareStatement("update order_matching set sell_qty=? where block_id=?");
					stmt.setInt(1, sqty);
					stmt.setInt(2, rs.getInt(5));
					stmt.executeUpdate();

					// change market price of stock caused by trade execution
					if (updateNeeded) {
						String symbol = rs.getString(2);
						stock.priceUpdate(bqty, sqty, symbol);
						
						stmt = con.prepareStatement("update order_matching set order_status=? where block_id=?");
						stmt.setInt(1, orderStatus_buy);
						stmt.setInt(2, rs.getInt(1));
						stmt.executeUpdate();

						stmt = con
								.prepareStatement("update order_matching set order_status=? where block_id=?");
						stmt.setInt(1, orderStatus_sell);
						stmt.setInt(2, rs.getInt(5));
						stmt.executeUpdate();
					}

					// updating quantity left to be executed in temp table after executing 1 order
					stmt = con.prepareStatement("update temp set sell_qty=? where block_id_sell=?");
					stmt.setInt(1, sqty);
					stmt.setInt(2, rs.getInt(5));
					stmt.executeUpdate();
					stmt = con.prepareStatement("update temp set buy_qty=? where block_id_buy=?");
					stmt.setInt(1, bqty);
					stmt.setInt(2, rs.getInt(1));
					stmt.executeUpdate();

				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
