package com.comp.em.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnection {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getExchangeConnection() throws SQLException {
		String url = "jdbc:mysql://10.207.60.33:3306/em"; // 
		String user = "root";
		String password = "7885";
		return DriverManager.getConnection(url, user, password);
	}
	public static Connection getTradeConnection() throws SQLException {
		String url = "jdbc:mysql://10.207.60.33:3306/tm"; // 
		String user = "root";
		String password = "7885";
		return DriverManager.getConnection(url, user, password);
	}

}
