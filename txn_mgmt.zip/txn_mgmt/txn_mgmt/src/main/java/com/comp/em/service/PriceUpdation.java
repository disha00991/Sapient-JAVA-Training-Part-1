package com.comp.em.service;

public interface PriceUpdation {

	void priceUpdate(int buy_qty, int sell_qty, String symbol);

}