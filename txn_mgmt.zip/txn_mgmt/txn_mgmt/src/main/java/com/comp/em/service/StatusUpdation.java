package com.comp.em.service;

public interface StatusUpdation {

	void statusUpdate();

}