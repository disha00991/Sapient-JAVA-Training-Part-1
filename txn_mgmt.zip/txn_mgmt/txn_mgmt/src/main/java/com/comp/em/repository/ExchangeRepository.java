package com.comp.em.repository;

public interface ExchangeRepository {

	void insertIntoExchange();

	void orderSegregation();
	
	void cleanTxnTables();

}