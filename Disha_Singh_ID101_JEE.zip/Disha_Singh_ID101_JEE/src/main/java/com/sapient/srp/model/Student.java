package com.sapient.srp.model;

public class Student {
	private String name;
	private String rollNo;
	private float percentage;
	
	public Student(String name, String rollNo, float percentage) {
		super();
		this.name = name;
		this.rollNo = rollNo;
		this.percentage = percentage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	
	
}
