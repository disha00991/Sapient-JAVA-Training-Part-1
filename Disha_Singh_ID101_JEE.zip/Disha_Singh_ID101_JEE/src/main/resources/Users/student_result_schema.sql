use student_result;
CREATE TABLE student_result.STUDENT(
ROLLNO VARCHAR(10),
NAME VARCHAR(30),
PERCENTAGE DECIMAL(3, 2));

select * from student_result.student;

CREATE TABLE student_result.marks(
ROLLNO VARCHAR(10),
subject VARCHAR(30),
scores DOUBLE);


insert into student_result.marks values("SAPIENT123", "English", 90.00);
insert into student_result.marks values("SAPIENT123", "Maths", 55.10);
insert into student_result.marks values("SAPIENT123", "CSE", 75.00);
insert into student_result.marks values("SAPIENT121", "English", 85.00);
insert into student_result.marks values("SAPIENT121", "Maths", 59.00);
insert into student_result.marks values("SAPIENT121", "CSE", 76.00);

select * from student_result.marks;