package com.sapient.srp.service;

import java.util.List;

import com.sapient.srp.model.Scores;
import com.sapient.srp.model.Student;
import com.sapient.srp.repository.AccountRepository;
import com.sapient.srp.repository.JdbcAccountRepository;

public class StudentServiceImpl implements StudentService {

	AccountRepository repository = new JdbcAccountRepository();

	public List<Scores> showMarks(Student student) {
		List<Scores> scores;
		if (repository.findAllScores(student.getRollNo()) == null) {// account does not exist
			throw new StudentNotFoundException("This account was not found!");
		} else {
			scores = repository.findAllScores(student.getRollNo());
		}
		return scores;
	}

}
