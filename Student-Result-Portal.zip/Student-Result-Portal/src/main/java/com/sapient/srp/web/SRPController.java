package com.sapient.srp.web;

import java.util.List;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sapient.srp.model.Scores;
import com.sapient.srp.model.Student;
import com.sapient.srp.repository.AccountRepository;
import com.sapient.srp.repository.JdbcAccountRepository;
import com.sapient.srp.service.StudentNotFoundException;
import com.sapient.srp.service.StudentService;
import com.sapient.srp.service.StudentServiceImpl;

@WebServlet(urlPatterns = {"/login", "/existing-student", "/showMarks"})
public class SRPController extends HttpServlet {
	private AccountRepository repository;
	private StudentService service;

	@Override
	public void init(ServletConfig config) throws ServletException {
		repository = new JdbcAccountRepository();
		service = new StudentServiceImpl();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String reqPath = req.getRequestURI();
		String path = reqPath.substring(reqPath.lastIndexOf("/"));
		req.setAttribute("path", path.substring(1));

		if (path.equals("/login")) {
			req.getRequestDispatcher("home.jsp").forward(req, resp);
		}
		
		String rollNo = req.getParameter("rollNo");
		String message = "Hi!";
		if (rollNo.length() != 10)
			message = "Length of roll number should be 10";
		//other validations
			
		req.setAttribute("rollNo", rollNo);

		Student student = null;

		if (path.equals("/existing-student")) {
			student = repository.find(rollNo);			
			
			//exception handling
			if (student == null) {
				throw new StudentNotFoundException("This account was not found!");
			}
			
			req.getSession().setAttribute("myStudent", student);
			resp.sendRedirect("service?msg="+message);
		}

		if (path.equals("/service")) {
			req.getRequestDispatcher("services.jsp").forward(req, resp);
		}

		if (path.equals("/showMarks")) {
			
			student = (Student) req.getSession().getAttribute("myStudent");
			List<Scores> score = service.showMarks(student);
			
			
			resp.sendRedirect("showMarks.jsp?msg=Hi!");
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String reqPath = req.getRequestURI();
		String path = reqPath.substring(reqPath.lastIndexOf("/"));

		String rollNo = req.getParameter("rollNo");
		req.setAttribute("rollNo", rollNo);

		Student student = null;

		

	}
}
