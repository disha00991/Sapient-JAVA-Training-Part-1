package com.sapient.srp.service;

public class StudentNotFoundException extends RuntimeException {

	public StudentNotFoundException(String message) {
		System.out.println("this student is not found");
	}
}
