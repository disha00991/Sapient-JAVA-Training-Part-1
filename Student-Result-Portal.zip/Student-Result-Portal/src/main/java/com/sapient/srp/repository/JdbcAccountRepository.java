package com.sapient.srp.repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sapient.srp.db.MySqlConnection;
import com.sapient.srp.model.Scores;
import com.sapient.srp.model.Status;
import com.sapient.srp.model.Student;

public class JdbcAccountRepository implements AccountRepository {

//finds student according to rollNo
	@Override
	public Student find(String rollNo) {
		Connection con = null;
		Student student = null;
		try {
			con = MySqlConnection.getMySqlconnection();
			String sql = "select * from student_result.student where ROLLNO=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, rollNo);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				student = new Student(rs.getString(2), rs.getString(1), rs.getFloat(3));
			}else {
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return student;
	}

//shows subject wise marks of student
	public List<Scores> findAllScores(String rollNo) {
		List<Scores> allScores = new ArrayList<Scores>();
		Connection con = null;
		Scores score = null;
		String status = "";
		try {
			con = MySqlConnection.getMySqlconnection();
			String sql = "select * from student_result.scores where ROLLNO=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, rollNo);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				if (rs.getFloat(2) >= 60)
					status = "Status.PASS";
				else 
					status = "Status.FAIL";
				score = new Scores(rs.getString(1), rs.getFloat(2), status);
				allScores.add(score);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return allScores;
	}
	


}
