package com.sapient.srp.model;

public enum Status {
	PASS, FAIL;
}
