package com.sapient.srp.repository;

import java.util.List;

import com.sapient.srp.model.Scores;
import com.sapient.srp.model.Student;

public interface AccountRepository {
	Student find(String rollNo);
	List<Scores> findAllScores(String rollNo);
}
