package com.sapient.srp.model;

public class Scores {
	private String subject;
	private float scores;
	String status;

	public Scores(String subject, float scores, String status) {
		super();
		this.subject = subject;
		this.scores = scores;
		this.status = status;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public float getScores() {
		return scores;
	}

	public void setScores(float scores) {
		this.scores = scores;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
